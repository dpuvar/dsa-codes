#include <iostream>
using namespace std;

int main()
{
    int T;
    cin >> T;
    while (T--)
    {
        int N;
        // Number of elements
        cin >> N;
        int arr[N];
        int listInd = 0;
        for (int i = 0; i < N; i++)
        {
            cin >> arr[i];
            if (i != 0 && listInd != -2 && arr[listInd] == arr[i])
            {
                listInd += 1; // 1 i=1
                for (int j = 0; j <= i; j++)
                {
                    if (listInd == j)
                    {
                        if (listInd == i)
                        {
                            listInd = -2;
                        }
                        continue;
                    }
                    if (arr[listInd] == arr[j])
                    {
                        if (listInd == i)
                        {
                            listInd = -2;
                            break;
                        }
                        listInd += 1;
                        j = 0;
                    }
                }
                cout << listInd + 1 << " ";
            }
            else if (listInd == -2)
            {
                listInd = i;
                for (int j = 0; j < i; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        listInd = -2;
                        break;
                    }
                }
                cout << listInd + 1 << " ";
            }
            else
            {
                cout << listInd + 1 << " ";
            }
        }
    }
}

// #include <bits/stdc++.h>
// using namespace std;

// int main()
// {
//     ios::sync_with_stdio(0);
//     cin.tie(0);
//     cout.tie(0);
//     int f;
//     cin >> f;
//     while (f--)
//     {
//         int t;
//         cin >> t;
//         int q[t];
//         int b[100001] = {0};
//         int c[100001] = {0};
//         for (int i = 0; i < t; i++)
//         {
//             cin >> q[i];
//             if (b[q[i]] == 0)
//             {
//                 b[q[i]] = i + 1;
//             }
//         }

//         set<int> p;
//         for (int i = 0; i < t; i++)
//         {
//             if (c[q[i]] == 0)
//             {
//                 p.insert(b[q[i]]);
//                 c[q[i]]++;
//                 cout << *p.begin() << " ";
//             }
//             else
//             {
//                 if (p.find(b[q[i]]) != p.end())
//                 {
//                     p.erase(p.find(b[q[i]]));
//                 }
//                 if (p.empty())
//                 {
//                     cout << -1 << " ";
//                 }
//                 else
//                 {
//                     cout << *p.begin() << " ";
//                 }
//             }
//         }
//         cout << endl;
//     }
//     return 0;
// }